package sync

import (
	"internal/task"
	"unsafe"
)

const waitGroupBubbleFlag = uint32(1 << 31)

type WaitGroup struct {
	futex    task.Futex
	lock     task.PMutex
	waiters  task.Stack
	counter  int
	waiting  int
	synctest unsafe.Pointer
}

func (wg *WaitGroup) Add(delta int) {
	if !synctestIsEnabled() {
		wg.addPlain(delta)
		return
	}

	currentBubble := task.Current().SynctestBubble
	wg.lock.Lock()
	if currentBubble == nil && wg.synctest == nil {
		wg.lock.Unlock()
		wg.addPlain(delta)
		return
	}
	if currentBubble != nil {
		if wg.synctest == nil {
			if !wg.futex.CompareAndSwap(0, waitGroupBubbleFlag) {
				wg.lock.Unlock()
				runtimeFatal("sync: WaitGroup.Add called from inside and outside synctest bubble")
			}
			wg.synctest = currentBubble
		} else if wg.synctest != currentBubble {
			wg.lock.Unlock()
			runtimeFatal("sync: WaitGroup.Add called from multiple synctest bubbles")
		}
	} else if wg.synctest != nil {
		wg.lock.Unlock()
		runtimeFatal("sync: WaitGroup.Add called from inside and outside synctest bubble")
	}

	if delta > 0 && wg.counter == 0 && wg.waiting != 0 {
		wg.lock.Unlock()
		panic("sync: WaitGroup misuse: Add called concurrently with Wait")
	}
	if delta > 0 && wg.counter > int(^uint32(0)>>1)-delta {
		wg.lock.Unlock()
		panic("sync: WaitGroup counter overflowed")
	}
	wg.counter += delta
	if wg.counter < 0 {
		wg.lock.Unlock()
		panic("sync: negative WaitGroup counter")
	}
	if wg.counter != 0 {
		wg.lock.Unlock()
		return
	}

	waiters := wg.waiters.Queue()
	if wg.waiting == 0 {
		wg.synctest = nil
		wg.futex.Store(0)
	}
	wg.lock.Unlock()

	for waiter := waiters.Pop(); waiter != nil; waiter = waiters.Pop() {
		scheduleTask(waiter)
	}
}

func (wg *WaitGroup) addPlain(delta int) {
	if delta > 0 {
		// Delta is positive.
		for {
			// Check for overflow.
			counter := wg.futex.Load()
			if synctestIsEnabled() && counter&waitGroupBubbleFlag != 0 {
				runtimeFatal("sync: WaitGroup.Add called from inside and outside synctest bubble")
			}
			if uint64(delta) > uint64(waitGroupBubbleFlag-1-counter) {
				panic("sync: WaitGroup counter overflowed")
			}

			// Add to the counter.
			if wg.futex.CompareAndSwap(counter, counter+uint32(delta)) {
				// Successfully added.
				return
			}
		}
	}

	// Delta is negative (or zero).
	for {
		counter := wg.futex.Load()
		if synctestIsEnabled() && counter&waitGroupBubbleFlag != 0 {
			runtimeFatal("sync: WaitGroup.Add called from inside and outside synctest bubble")
		}

		// Check for underflow.
		if uint32(-delta) > counter {
			panic("sync: negative WaitGroup counter")
		}

		// Subtract from the counter.
		if !wg.futex.CompareAndSwap(counter, counter-uint32(-delta)) {
			// Could not swap, trying again.
			continue
		}

		// If the counter is zero, everything is done and the waiters should
		// be resumed.
		// When there are multiple thread, there is a chance for the counter
		// to go to zero, WakeAll to be called, and then the counter to be
		// incremented again before a waiting goroutine has a chance to
		// check the new (zero) value. However the last increment is
		// explicitly given in the docs as something that should not be
		// done:
		//
		//   > Note that calls with a positive delta that occur when the
		//   > counter is zero must happen before a Wait.
		//
		// So we're fine here.
		if counter-uint32(-delta) == 0 {
			// TODO: this is not the most efficient implementation possible
			// because we wake up all waiters unconditionally, even if there
			// might be none. Though since the common usage is for this to
			// be called with at least one waiter, it's probably fine.
			wg.futex.WakeAll()
		}

		// Successfully swapped (and woken all waiting tasks if needed).
		return
	}
}

func (wg *WaitGroup) Done() {
	wg.Add(-1)
}

func (wg *WaitGroup) Wait() {
	if !synctestIsEnabled() {
		wg.waitPlain()
		return
	}

	wg.lock.Lock()
	if wg.synctest == nil {
		wg.lock.Unlock()
		wg.waitPlain()
		return
	}
	current := task.Current()
	if wg.counter == 0 {
		if wg.waiting == 0 {
			wg.synctest = nil
			wg.futex.Store(0)
		}
		wg.lock.Unlock()
		return
	}
	wg.waiting++
	wg.waiters.Push(current)
	// An unbubbled waiter is allowed, but its wait is not durable.
	if wg.synctest != nil && wg.synctest == current.SynctestBubble {
		synctestBlock(current)
	}
	wg.lock.Unlock()

	task.Pause()

	wg.lock.Lock()
	wg.waiting--
	if wg.counter != 0 {
		wg.lock.Unlock()
		panic("sync: WaitGroup is reused before previous Wait has returned")
	}
	if wg.waiting == 0 {
		wg.synctest = nil
		wg.futex.Store(0)
	}
	wg.lock.Unlock()
}

func (wg *WaitGroup) waitPlain() {
	for {
		counter := wg.futex.Load()
		if counter == 0 {
			return // everything already finished
		}
		if wg.futex.Wait(counter) {
			// Successfully woken by WakeAll (in wg.Add).
			return
		}
	}
}

func (wg *WaitGroup) Go(f func()) {
	wg.Add(1)
	go func() {
		defer wg.Done()
		f()
	}()
}

//go:linkname synctestBlock runtime.synctestBlock
func synctestBlock(*task.Task)

//go:linkname synctestIsEnabled runtime.synctestIsEnabled
func synctestIsEnabled() bool
