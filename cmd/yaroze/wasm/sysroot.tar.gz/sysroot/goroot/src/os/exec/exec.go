// Package exec is the shape of upstream's os/exec with nothing behind it:
// a program TinyGo compiles has no processes to start. Commands are made
// as upstream makes them and fail when run, so that code written against
// upstream, go/build's search for the go command among it, compiles and
// takes its error path. Upstream's Start would also start goroutines,
// which a build without a scheduler cannot have anywhere it can reach.
package exec

import (
	"errors"
	"io"
	"os"
	"strings"
)

// ErrNotFound is the error resulting if a path search failed to find an
// executable file.
var ErrNotFound = errors.New("executable file not found in $PATH")

// ErrDot indicates that a path lookup resolved to an executable in the
// current directory due to ‘.’ being in the path.
var ErrDot = errors.New("cannot run executable found relative to current directory")

// ErrWaitDelay is returned by Cmd.Wait if the process exits with a
// successful status code but its output pipes are not closed before the
// command's WaitDelay expires.
var ErrWaitDelay = errors.New("exec: WaitDelay expired before I/O complete")

var errNoProcesses = errors.New("exec: this program cannot start processes")

// Error is returned by LookPath when it fails to classify a file as an
// executable.
type Error struct {
	// Name is the file name for which the error occurred.
	Name string
	// Err is the underlying error.
	Err error
}

func (e *Error) Error() string {
	return "exec: " + strconv(e.Name) + ": " + e.Err.Error()
}

func (e *Error) Unwrap() error { return e.Err }

// strconv quotes a name as strconv.Quote would, near enough for an error.
func strconv(s string) string {
	return `"` + strings.ReplaceAll(s, `"`, `\"`) + `"`
}

// An ExitError reports an unsuccessful exit by a command.
type ExitError struct {
	*os.ProcessState

	// Stderr holds a subset of the standard error output from the
	// Cmd.Output method if standard error was not otherwise being
	// collected.
	Stderr []byte
}

func (e *ExitError) Error() string {
	return e.ProcessState.String()
}

// Cmd represents an external command being prepared or run. It has the
// fields of upstream's that callers set.
type Cmd struct {
	Path         string
	Args         []string
	Env          []string
	Dir          string
	Stdin        io.Reader
	Stdout       io.Writer
	Stderr       io.Writer
	ExtraFiles   []*os.File
	Process      *os.Process
	ProcessState *os.ProcessState
	Err          error
	Cancel       func() error
	WaitDelay    int64
}

// Command returns the Cmd struct to execute the named program with the
// given arguments.
func Command(name string, arg ...string) *Cmd {
	cmd := &Cmd{
		Path: name,
		Args: append([]string{name}, arg...),
	}
	if !strings.Contains(name, "/") {
		cmd.Err = &Error{name, ErrNotFound}
	}
	return cmd
}

// String returns a human-readable description of c.
func (c *Cmd) String() string {
	if c.Err != nil {
		return strings.Join(c.Args, " ")
	}
	return c.Path + " " + strings.Join(c.Args[1:], " ")
}

// Environ returns a copy of the environment in which the command would be
// run as it is currently configured.
func (c *Cmd) Environ() []string {
	if c.Env != nil {
		return append([]string(nil), c.Env...)
	}
	return os.Environ()
}

// Run starts the specified command and waits for it to complete, which here
// means failing: there are no processes.
func (c *Cmd) Run() error {
	return c.Start()
}

// Start starts the specified command, which here means failing.
func (c *Cmd) Start() error {
	if c.Err != nil {
		return c.Err
	}
	return errNoProcesses
}

// Wait waits for the command to exit; no command was ever started.
func (c *Cmd) Wait() error {
	return errors.New("exec: not started")
}

// Output runs the command and returns its standard output.
func (c *Cmd) Output() ([]byte, error) {
	return nil, c.Run()
}

// CombinedOutput runs the command and returns its combined standard output
// and standard error.
func (c *Cmd) CombinedOutput() ([]byte, error) {
	return nil, c.Run()
}

// LookPath searches for an executable named file; nothing is ever found.
func LookPath(file string) (string, error) {
	return "", &Error{file, ErrNotFound}
}
