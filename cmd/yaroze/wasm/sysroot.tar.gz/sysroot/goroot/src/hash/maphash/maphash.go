// Package maphash provides hash functions on byte sequences and comparable
// values, with the API of the standard library's package.
//
// The standard implementation reaches into internal/runtime/maps and
// internal/abi for the map hasher, which TinyGo's runtime does not have, so
// this version hashes bytes itself and hashes comparable values through the
// runtime's interface hash, the same hash that map[any] keys use.
package maphash

import (
	"hash"
	"unsafe"
)

// A Seed is a random value that selects the specific hash function computed
// by a Hash.
type Seed struct {
	s uint64
}

// Bytes returns the hash of b with the given seed.
func Bytes(seed Seed, b []byte) uint64 {
	if seed.s == 0 {
		panic("maphash: use of uninitialized Seed")
	}
	return hashBytes(b, seed.s)
}

// String returns the hash of s with the given seed.
func String(seed Seed, s string) uint64 {
	return Bytes(seed, unsafe.Slice(unsafe.StringData(s), len(s)))
}

// A Hash computes a seeded hash of a byte sequence.
type Hash struct {
	_     [0]func()
	seed  Seed
	state Seed
	buf   [bufSize]byte
	n     int
}

const bufSize = 128

func (h *Hash) initSeed() {
	if h.seed.s == 0 {
		seed := MakeSeed()
		h.seed = seed
		h.state = seed
	}
}

// WriteByte adds b to the sequence of bytes hashed by h.
func (h *Hash) WriteByte(b byte) error {
	if h.n == len(h.buf) {
		h.flush()
	}
	h.buf[h.n] = b
	h.n++
	return nil
}

// Write adds b to the sequence of bytes hashed by h.
func (h *Hash) Write(b []byte) (int, error) {
	size := len(b)
	if h.n > 0 && h.n+len(b) > len(h.buf) {
		k := copy(h.buf[h.n:], b)
		h.n = len(h.buf)
		b = b[k:]
		h.flush()
	}
	if len(b) > len(h.buf) {
		h.initSeed()
		h.state.s = hashBytes(b, h.state.s)
		return size, nil
	}
	h.n += copy(h.buf[h.n:], b)
	return size, nil
}

// WriteString adds the bytes of s to the sequence of bytes hashed by h.
func (h *Hash) WriteString(s string) (int, error) {
	return h.Write(unsafe.Slice(unsafe.StringData(s), len(s)))
}

// Seed returns h's seed value.
func (h *Hash) Seed() Seed {
	h.initSeed()
	return h.seed
}

// SetSeed sets h to use seed, and resets any data written.
func (h *Hash) SetSeed(seed Seed) {
	if seed.s == 0 {
		panic("maphash: use of uninitialized Seed")
	}
	h.seed = seed
	h.state = seed
	h.n = 0
}

// Reset discards all bytes added to h.
func (h *Hash) Reset() {
	h.initSeed()
	h.state = h.seed
	h.n = 0
}

func (h *Hash) flush() {
	if h.n != len(h.buf) {
		panic("maphash: flush of partially full buffer")
	}
	h.initSeed()
	h.state.s = hashBytes(h.buf[:h.n], h.state.s)
	h.n = 0
}

// Sum64 returns h's current 64-bit value.
func (h *Hash) Sum64() uint64 {
	h.initSeed()
	return hashBytes(h.buf[:h.n], h.state.s)
}

// MakeSeed returns a new random seed.
func MakeSeed() Seed {
	var s uint64
	for {
		s = runtime_fastrand64()
		if s != 0 {
			break
		}
	}
	return Seed{s: s}
}

// Sum appends the hash's current 64-bit value to b.
func (h *Hash) Sum(b []byte) []byte {
	x := h.Sum64()
	return append(b,
		byte(x>>0), byte(x>>8), byte(x>>16), byte(x>>24),
		byte(x>>32), byte(x>>40), byte(x>>48), byte(x>>56))
}

// Size returns h's hash value size, 8 bytes.
func (h *Hash) Size() int { return 8 }

// BlockSize returns h's block size.
func (h *Hash) BlockSize() int { return len(h.buf) }

// Clone implements hash.Cloner.
func (h *Hash) Clone() (hash.Cloner, error) {
	r := *h
	return &r, nil
}

// Comparable returns the hash of comparable value v with the given seed,
// such that Comparable(s, v1) == Comparable(s, v2) if v1 == v2.
func Comparable[T comparable](seed Seed, v T) uint64 {
	if seed.s == 0 {
		panic("maphash: use of uninitialized Seed")
	}
	return comparableHash(any(v), seed.s)
}

// WriteComparable adds x to the data hashed by h.
func WriteComparable[T comparable](h *Hash, x T) {
	h.initSeed()
	v := comparableHash(any(x), h.state.s)
	var b [8]byte
	for i := range b {
		b[i] = byte(v >> (8 * i))
	}
	h.Write(b[:])
}

// comparableHash hashes an interface value through the runtime, as a
// map[any] would, folding two 32-bit hashes with different seeds into one
// 64-bit value.
func comparableHash(v any, seed uint64) uint64 {
	lo := runtime_hashmapInterfaceHash(v, uintptr(uint32(seed)))
	hi := runtime_hashmapInterfaceHash(v, uintptr(uint32(seed>>32)^0x9e3779b9))
	return uint64(hi)<<32 | uint64(lo)
}

// hashBytes is a 64-bit multiply-rotate hash over b, seeded with seed. The
// quality bar is the same as the standard package's: good distribution, no
// cryptographic strength.
func hashBytes(b []byte, seed uint64) uint64 {
	const (
		m1 = 0xa0761d6478bd642f
		m2 = 0xe7037ed1a0b428db
		m3 = 0x8ebc6af09c88c6e3
		m4 = 0x589965cc75374cc3
	)
	h := seed ^ (uint64(len(b)) * m1)
	for len(b) >= 8 {
		h = mix(h^load64(b), m2)
		b = b[8:]
	}
	if len(b) > 0 {
		var tail uint64
		for i, c := range b {
			tail |= uint64(c) << (8 * i)
		}
		h = mix(h^tail, m3)
	}
	return mix(h, m4)
}

func load64(b []byte) uint64 {
	return uint64(b[0]) | uint64(b[1])<<8 | uint64(b[2])<<16 | uint64(b[3])<<24 |
		uint64(b[4])<<32 | uint64(b[5])<<40 | uint64(b[6])<<48 | uint64(b[7])<<56
}

func mix(a, b uint64) uint64 {
	a *= b
	a ^= a >> 32
	a *= 0x9fb21c651e98df25
	a ^= a >> 29
	return a
}

//go:linkname runtime_fastrand64 runtime.fastrand64
func runtime_fastrand64() uint64

//go:linkname runtime_hashmapInterfaceHash runtime.hashmapInterfaceHash
func runtime_hashmapInterfaceHash(itf interface{}, seed uintptr) uint32

// Hasher is a type that implements hashing and equality for type T.
type Hasher[T any] interface {
	// Hash updates hash to reflect the contents of value.
	Hash(hash *Hash, value T)
	// Equal reports whether two values are equal.
	Equal(x, y T) bool
}

// ComparableHasher is an implementation of Hasher for comparable types,
// using Comparable for hashing and == for equality.
type ComparableHasher[T comparable] struct{}

func (ComparableHasher[T]) Hash(h *Hash, v T) { WriteComparable(h, v) }
func (ComparableHasher[T]) Equal(x, y T) bool { return x == y }
