//go:build yaroze

package disc

import (
	"unsafe"

	"go.chrisrx.dev/psx/internal/discrecord"
)

// The record of a File on the console, where a pointer and a string's
// length are 32 bits, is what mkdisc looks for; these fail the build if it
// drifts from what discrecord says. On a host the type is wider and nothing
// reads it as a record.
var (
	_ = [1]struct{}{}[unsafe.Sizeof(record{})-discrecord.Size]
	_ = [1]struct{}{}[unsafe.Offsetof(record{}.Name)-discrecord.OffName]
	_ = [1]struct{}{}[unsafe.Offsetof(record{}.src)-discrecord.OffSrc]
	_ = [1]struct{}{}[unsafe.Offsetof(record{}.sector)-discrecord.OffSector]
	_ = [1]struct{}{}[unsafe.Offsetof(record{}.size)-discrecord.OffSize]
	_ = [1]struct{}{}[unsafe.Offsetof(record{}.dst)-discrecord.OffDst]
)
