// A ship down an endless tunnel, shooting waves of enemies under three
// colored lights.
//
// A port of L. Evans's Net Yaroze game demo "tunnel" (Sony, 1997), the last
// of the tutorial series it was built up over: a ship flying down an
// endless tunnel, shooting waves of enemies. The tunnel is rings of four
// scaled squares that slide towards the ship and go round to the far end
// again; the near ones are subdivided so the perspective holds up. Fog,
// three colored lights, one of them always circling, and semi-transparent
// sprites for shots, explosions and pick-ups make it the most of the
// machine's lighting any of the examples use. Its sound is a VAB: a tune
// started once and left playing, and sound effects keyed on and off by
// hand. The score is drawn in sprites cut from a font texture.
//
// Enemies come in waves: helixes of fighters circling as they come, some
// switching direction or darting as one, lone attackers that jiggle, evade
// or circle while they fire, swarms of insect ships, and every so often a
// robot. Pick-ups give a life, faster shots or movement, or set the lights
// or the view swinging. The game gets faster every thousand frames.
//
// Differences from the original:
//
//   - The data is read off the disc to the addresses the original's batch
//     script sent it to.
//   - The random numbers are seeded with a constant. The original seeds
//     them from the seconds of the time it was compiled.
//   - Quitting returns to the BIOS. The original first saves the screen to
//     RAM for the serial console to fetch, and calls exit.
//   - The direction a shot is fired in is normalized in integers, exactly;
//     the original uses floating point.
//   - What the original prints to the serial console is left out, and so
//     are its assertions.
//
// # Controls
//
// The directional buttons and L1 and L2 move the ship, R1 fires, Select
// makes moves faster, Select and L2 step slowly, Start pauses, and Start and
// Select together quit.
package main

import (
	"go.chrisrx.dev/psx/disc"
	"go.chrisrx.dev/psx/examples/internal/demo"
	"go.chrisrx.dev/psx/examples/internal/lpge"
	"go.chrisrx.dev/psx/yaroze"
)

const (
	screenW, screenH = 320, 240
	packetMax        = 2048 * 24
	otLength         = 9

	// The square model's own size.
	squareSize = 128
)

// The models, the textures and the sound bank, read into the program's
// own memory, in buffers of whole sectors.
var (
	squareData   [(112 + 2047) / 2048 * 512]uint32
	shipData     [(2044 + 2047) / 2048 * 512]uint32
	mainData     [(2112 + 2047) / 2048 * 512]uint32
	fireData     [(576 + 2047) / 2048 * 512]uint32
	multipleData [(18972 + 2047) / 2048 * 512]uint32
	multiTIMData [(16928 + 2047) / 2048 * 512]uint32
	mascotsData  [(25024 + 2047) / 2048 * 512]uint32
	asciiData    [(2112 + 2047) / 2048 * 512]uint32
	vhData       [(5152 + 2047) / 2048 * 512]uint32
	vbData       [(440544 + 2047) / 2048 * 512]uint32

	squareFile   = disc.Register("ASSETS/TEN.TMD", "assets/TEN.TMD").Into(squareData[:])
	shipFile     = disc.Register("ASSETS/THESHIP.TMD", "assets/THESHIP.TMD").Into(shipData[:])
	mainFile     = disc.Register("ASSETS/WAVE09.TIM", "assets/WAVE09.TIM").Into(mainData[:])
	fireFile     = disc.Register("ASSETS/FIRE7.TIM", "assets/FIRE7.TIM").Into(fireData[:])
	multipleFile = disc.Register("ASSETS/ENEMY.TMD", "assets/ENEMY.TMD").Into(multipleData[:])
	multiTIMFile = disc.Register("ASSETS/MULTI3.TIM", "assets/MULTI3.TIM").Into(multiTIMData[:])
	mascotsFile  = disc.Register("ASSETS/MASCOTS2.TIM", "assets/MASCOTS2.TIM").Into(mascotsData[:])
	asciiFile    = disc.Register("ASSETS/ASCII2.TIM", "assets/ASCII2.TIM").Into(asciiData[:])
	vh           = disc.Register("ASSETS/LEWIS.VH", "assets/LEWIS.VH").Into(vhData[:])
	vb           = disc.Register("ASSETS/LEWIS.VB", "assets/LEWIS.VB").Into(vbData[:])

	squareModel   = yaroze.TMD(squareData[:])
	shipModel     = yaroze.TMD(shipData[:])
	multipleModel = yaroze.TMD(multipleData[:])
	mainTIM       = yaroze.TIM(mainData[:])
	fireTIM       = yaroze.TIM(fireData[:])
	multipleTIM   = yaroze.TIM(multiTIMData[:])
	mascotsTIM    = yaroze.TIM(mascotsData[:])
	asciiTIM      = yaroze.TIM(asciiData[:])
)

var (
	wot        [2]yaroze.GsOT
	wtags      [2][1 << otLength]yaroze.GsOT_TAG
	packetArea [2][packetMax / 4]uint32

	view       yaroze.GsRVIEW2
	projection int32

	// Where the view sits, relative to the world's origin.
	viewpointX, viewpointY, viewpointZ int32

	lights    [3]yaroze.GsF_LIGHT
	fogging   yaroze.GsFOGPARAM
	lightMode int32

	mainTexture, fireTexture, multipleTexture, mascotsTexture, asciiTexture yaroze.GsIMAGE

	frameNumber int32

	// displayed is what the world clipping leaves to draw.
	displayed [lpge.MaxObjects]*lpge.Handler

	quit bool
)

func main() {
	if !initializeAll() {
		return
	}
	flyingSequence()

	side := yaroze.GsGetActiveBuff()
	for !quit {
		handleDelayedActionList()
		if quit {
			break
		}
		checkForEndOfLevel()

		registerNumber("frame ", frameNumber, 50, 50)
		registerNumber("health ", playersShip.CurrentHealth, 50, 60)
		registerNumber("lives ", playersLives, 50, 70)
		registerNumber("score ", playersShip.MeritRating, 50, 80)
		registerNumber("level ", levelNumber, 50, 90)

		frameNumber++
		dealWithControllerPad()

		if lightOscillation {
			oscillateLighting()
		}
		if viewOscillation {
			oscillateView()
		}
		minorOscillateLighting()
		handleSound()

		yaroze.GsSetWorkBase(yaroze.Packets(&packetArea[side][0]))
		yaroze.GsClearOt(0, 0, &wot[side])

		handleAllObjects()
		updateTheTunnel()
		yaroze.GsSetRefView2(&view)

		drawObjects(performWorldClipping(), &wot[side])
		displayTextStrings(&wot[side])

		yaroze.VSync(0)
		yaroze.ResetGraph(1)
		yaroze.GsSwapDispBuff()
		yaroze.GsSortClear(0, 0, 4, &wot[side])
		yaroze.GsDrawOt(&wot[side])
		side ^= 1
		yaroze.FntFlush(-1)
	}
	yaroze.ResetGraph(3)
	cleanUpSound()
}

// drawObjects sorts the first n displayed objects into an ordering table.
func drawObjects(n int, ot *yaroze.GsOT) {
	for _, o := range displayed[:n] {
		if o.DisplayFlag == lpge.TMD {
			var ls yaroze.MATRIX
			yaroze.GsGetLs(&o.Coord, &ls)
			yaroze.GsSetLightMatrix(&ls)
			yaroze.GsSetLsMatrix(&ls)
			yaroze.GsSortObject4(&o.Handler, ot, 3, yaroze.Scratch())
		} else {
			z := sortSpriteObjectPosition(o)
			yaroze.GsSortSprite(&o.Sprite, ot, z)
		}
	}
}

// levelTime is how many frames a level lasts: the original's extremely
// crude notion of a level.
const levelTime = 1000

func checkForEndOfLevel() {
	if actual := frameNumber/levelTime + 1; levelNumber < actual {
		levelNumber++
		handleLevelUpdating()
	}
}

// sortSpriteObjectPosition places an object drawn as a sprite where its
// position projects to on screen, scaled for its distance, and returns its
// depth in the ordering table.
func sortSpriteObjectPosition(o *lpge.Handler) uint16 {
	ws := yaroze.GsWSMATRIX()
	yaroze.PushMatrix()
	var screen yaroze.VECTOR
	yaroze.ApplyMatrixLV(ws, &o.Position, &screen)
	screen.Vx += ws.T[0]
	screen.Vy += ws.T[1]
	screen.Vz += ws.T[2]
	if screen.Vz == 0 {
		// The original returns here without popping the matrix.
		return 0
	}
	visualX := int32(o.Sprite.W) * projection / screen.Vz
	visualY := int32(o.Sprite.H) * projection / screen.Vz
	o.Sprite.X = int16(screen.Vx*projection/screen.Vz - visualX/2)
	o.Sprite.Y = int16(screen.Vy*projection/screen.Vz - visualY/2)
	o.Sprite.Scalex = int16(o.ScaleX * projection / screen.Vz)
	o.Sprite.Scaley = int16(o.ScaleY * projection / screen.Vz)
	yaroze.PopMatrix()

	if screen.Vz < projection/2 {
		o.Sprite.Attribute |= yaroze.GsDOFF
	} else {
		o.Sprite.Attribute &^= yaroze.GsDOFF
	}
	return uint16(screen.Vz >> 6)
}

// performWorldClipping puts the living objects not too far down the tunnel
// into displayed, and returns how many there are.
func performWorldClipping() int {
	const clipDistance = squareSize * 8
	n := 0
	for _, o := range &lpge.Objects {
		if o != nil && o.Alive && o.Coord.Coord.T[2] < clipDistance {
			displayed[n] = o
			n++
		}
	}
	return n
}

// performBogusWorldClipping puts every living object into displayed.
func performBogusWorldClipping() int {
	n := 0
	for _, o := range &lpge.Objects {
		if o != nil && o.Alive {
			displayed[n] = o
			n++
		}
	}
	return n
}

func dealWithControllerPad() {
	pad := yaroze.PadRead()
	if pad&yaroze.PADstart != 0 && pad&yaroze.PADselect != 0 {
		registerDelayedAction(quitProgram, 1)
	}
	speed := int32(1)
	if pad&yaroze.PADselect != 0 {
		speed = 10
	}
	// Select and L2: step slowly.
	if pad&yaroze.PADselect != 0 && pad&yaroze.PADL2 != 0 {
		count := yaroze.VSync(-1)
		for count+25 > yaroze.VSync(-1) {
		}
		return
	}

	if playerInteractive {
		s := &playersShip
		by := s.MovementSpeed * speed
		if pad&yaroze.PADL1 != 0 {
			s.Position.Vz -= by
		}
		if pad&yaroze.PADL2 != 0 {
			s.Position.Vz += by
		}
		if pad&yaroze.PADLup != 0 {
			s.Position.Vy -= by
		}
		if pad&yaroze.PADLdown != 0 {
			s.Position.Vy += by
		}
		if pad&yaroze.PADLleft != 0 {
			s.Position.Vx -= by
		}
		if pad&yaroze.PADLright != 0 {
			s.Position.Vx += by
		}
		s.Position.Vx = keepWithinRange(s.Position.Vx, playerMinX, playerMaxX)
		s.Position.Vy = keepWithinRange(s.Position.Vy, playerMinY, playerMaxY)
		s.Position.Vz = keepWithinRange(s.Position.Vz, playerMinZ, sectionLength)
		if pad&yaroze.PADR1 != 0 {
			m := &s.Coord.Coord.M
			// Negated in z because of the way the ship model points.
			dir := yaroze.VECTOR{Vx: int32(m[2][0]), Vy: int32(m[2][1]), Vz: -int32(m[2][2])}
			handleObjectContinuousFiring(s, &dir)
		}
	}

	for pad&yaroze.PADstart != 0 { // pause
		pad = yaroze.PadRead()
	}
}

func initializeAll() bool {
	yaroze.PadInit()

	// The squares' scaling, for smoother walls; set and never used.
	scalingVector = yaroze.VECTOR{Vx: 7659, Vy: 7059, Vz: 7779}

	precompileCircularPositions()
	initializeDelayedActionList()

	yaroze.GsInitGraph(screenW, screenH, yaroze.GsINTER|yaroze.GsOFSGPU, 1, 0)
	yaroze.GsDefDispBuff(0, 0, 0, screenH)
	yaroze.GsInit3D()
	for i := range wot {
		wot[i].Length = otLength
		wot[i].Org = &wtags[i][0]
		yaroze.GsClearOt(0, 0, &wot[i])
	}
	yaroze.FntLoad(960, 256)
	yaroze.FntOpen(0, 40, 256, 200, 0, 512)

	if missing := demo.Load(disc.Registered(), nil); missing != "" {
		basicText[0].Reset()
		basicText[0].WriteString("could not read\n").WriteString(missing)
		dummyGuiLoopForTextPrinting(1, yaroze.PADstart|yaroze.PADselect)
		yaroze.ResetGraph(3)
		return false
	}

	initializeSound()
	yaroze.Srand(randomSeed)

	initializeView()
	initializeLighting()

	lpge.ProperInitializeTexture(mainTIM, &mainTexture)
	lpge.ProperInitializeTexture(fireTIM, &fireTexture)
	lpge.ProperInitializeTexture(multipleTIM, &multipleTexture)
	lpge.ProperInitializeTexture(mascotsTIM, &mascotsTexture)
	lpge.ProperInitializeTexture(asciiTIM, &asciiTexture)

	initializeTextStrings()
	initializeObjects()
	initializeTunnel()
	return true
}

// randomSeed stands in for the original's seed, the sum of the two digits
// of the seconds it was compiled at: as if at 12:00:00.
const randomSeed = '0' + '0'

// rand is the C library's rand, as an int32.
func rand() int32 { return yaroze.Rand() }

func initializeView() {
	projection = 192
	yaroze.GsSetProjection(projection)
	viewpointX, viewpointY, viewpointZ = 0, 0, -220
	view = yaroze.GsRVIEW2{Vpx: viewpointX, Vpy: viewpointY, Vpz: viewpointZ, Super: nil}
	yaroze.GsSetRefView2(&view)
}

func initializeLighting() {
	sortTheFlatLights()
	yaroze.GsSetAmbient(yaroze.ONE/4, yaroze.ONE/4, yaroze.ONE/4)
	fogging = yaroze.GsFOGPARAM{Dqa: -960, Dqb: 5120 * 5120, Bfc: 4}
	yaroze.GsSetFogParam(&fogging)
	lightMode = 1 // with fog
	yaroze.GsSetLightMode(lightMode)
}

// sortTheFlatLights sets the two purple lights shining across the tunnel.
func sortTheFlatLights() {
	lights[0] = yaroze.GsF_LIGHT{Vx: 1, Vy: 1, Vz: 1, R: 128, G: 42, B: 128}
	yaroze.GsSetFlatLight(0, &lights[0])
	lights[1] = yaroze.GsF_LIGHT{Vx: -1, Vy: -1, Vz: 1, R: 128, G: 42, B: 128}
	yaroze.GsSetFlatLight(1, &lights[1])
}

const lightingCycleTime = 120

// oscillateLighting turns the two lights, blue now, round the tunnel's
// axis, a turn every two seconds.
func oscillateLighting() {
	angle := frameNumber % lightingCycleTime * (4096 / lightingCycleTime)
	lights[0].R, lights[0].G, lights[0].B = 0, 0, 64
	lights[1].R, lights[1].G, lights[1].B = 0, 0, 64
	lights[0].Vx, lights[0].Vy, lights[0].Vz = lpge.Rcos(angle), lpge.Rsin(angle), 0
	lights[1].Vx, lights[1].Vy, lights[1].Vz = -lights[0].Vx, -lights[0].Vy, 0
	for i := range 2 {
		yaroze.GsSetFlatLight(int32(i), &lights[i])
	}
}

const minorOscillationPeriod = 60

// minorOscillateLighting turns the third light round the tunnel's axis, a
// turn a second, all the time.
func minorOscillateLighting() {
	angle := frameNumber % minorOscillationPeriod * (4096 / minorOscillationPeriod)
	lights[2] = yaroze.GsF_LIGHT{Vx: lpge.Rcos(angle), Vy: lpge.Rsin(angle), R: 128, G: 12, B: 128}
	yaroze.GsSetFlatLight(2, &lights[2])
}

// View oscillations, a pick-up's effect.
const (
	leftToRight = iota
	upAndDown
	circlingClockwise
	circlingAnticlockwise
)

var (
	lightOscillation, viewOscillation bool

	viewDistortionMode    int32
	oldViewDistortionMode int32 = leftToRight

	viewHorizontalVelocity, viewVerticalVelocity int32
	viewBaseVelocity                             int32 = 2
	viewAngle                                    int32
	viewAngularSpeed                             int32 = yaroze.ONE / 128
	viewOscillationJustBegun                     bool
)

func oscillateView() {
	if viewOscillationJustBegun {
		switch viewDistortionMode {
		case leftToRight:
			viewHorizontalVelocity = viewBaseVelocity - 2*viewBaseVelocity*(rand()%2)
		case upAndDown:
			viewVerticalVelocity = viewBaseVelocity - 2*viewBaseVelocity*(rand()%2)
		case circlingClockwise, circlingAnticlockwise:
			viewAngle = rand() % yaroze.ONE
		}
		viewOscillationJustBegun = false
	}
	switch viewDistortionMode {
	case leftToRight:
		if v := view.Vpx + viewHorizontalVelocity; v < playerMinX || v > playerMaxX {
			viewHorizontalVelocity = -viewHorizontalVelocity
		}
		view.Vpx += viewHorizontalVelocity
	case upAndDown:
		if v := view.Vpy + viewVerticalVelocity; v < playerMinY || v > playerMaxY {
			viewVerticalVelocity = -viewVerticalVelocity
		}
		view.Vpy += viewVerticalVelocity
	case circlingClockwise:
		viewAngle += viewAngularSpeed
		view.Vpx = radius * lpge.Rcos(viewAngle) >> 12
		view.Vpy = radius * lpge.Rsin(viewAngle) >> 12
	case circlingAnticlockwise:
		viewAngle -= viewAngularSpeed
		view.Vpx = radius * lpge.Rcos(viewAngle) >> 12
		view.Vpy = radius * lpge.Rsin(viewAngle) >> 12
	}
}

func keepWithinRange(v, lo, hi int32) int32 {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func abs(v int32) int32 {
	if v < 0 {
		return -v
	}
	return v
}

// The score and the like are drawn in sprites cut from a font texture,
// a letter or a digit each, eight pixels square.

const (
	maxTextStrings  = 20
	maxStringLength = 50
)

type textString struct {
	x, y   int16
	length int
	data   [maxStringLength]byte
}

var (
	letterSprites [26]yaroze.GsSPRITE
	numberSprites [10]yaroze.GsSPRITE
	allStrings    [maxTextStrings]textString

	numberBuf [maxStringLength]byte
	number    yaroze.Buffer
)

func initializeTextStrings() {
	for i := range letterSprites {
		s := &letterSprites[i]
		lpge.LinkSpriteToImageInfo(s, &asciiTexture)
		s.W, s.H = 8, 8
		if i < 15 {
			s.U += uint8(8 + i*8)
			s.V += 16
		} else {
			s.U += uint8((i - 15) * 8)
			s.V += 24
		}
	}
	for i := range numberSprites {
		s := &numberSprites[i]
		lpge.LinkSpriteToImageInfo(s, &asciiTexture)
		s.W, s.H = 8, 8
		s.U += uint8(i * 8)
		s.V += 8
	}
	for i := range allStrings {
		allStrings[i] = textString{}
	}
	number.Init(numberBuf[:])
}

// registerNumber queues a label and a number, and a newline, to be drawn at
// x, y this frame, as the original's sprintf and RegisterTextStringForDisplay
// do.
func registerNumber(label string, n int32, x, y int16) {
	number.Reset()
	number.WriteString(label).WriteInt(n).WriteString("\n")
	registerTextStringForDisplay(number.Bytes(), x, y)
}

func registerTextStringForDisplay(s []byte, x, y int16) {
	for i := range allStrings {
		t := &allStrings[i]
		if t.length == 0 {
			t.x, t.y = x, y
			t.length = copy(t.data[:], s)
			return
		}
	}
}

// displayTextStrings sorts the queued strings into an ordering table, a
// sprite a character, and empties the queue. A character the font does not
// have still takes its space.
func displayTextStrings(ot *yaroze.GsOT) {
	for i := range allStrings {
		t := &allStrings[i]
		if t.length == 0 {
			continue
		}
		x := t.x
		for _, c := range t.data[:t.length] {
			if s := spriteForCharacter(c); s != nil {
				s.X, s.Y = x, t.y
				yaroze.GsSortSprite(s, ot, 0)
			}
			x += 8
		}
		t.length = 0
	}
}

func spriteForCharacter(c byte) *yaroze.GsSPRITE {
	switch {
	case c >= 'A' && c <= 'Z':
		return &letterSprites[c-'A']
	case c >= 'a' && c <= 'z':
		return &letterSprites[c-'a']
	case c >= '0' && c <= '9':
		return &numberSprites[c-'0']
	}
	return nil
}
